<?php

function BaTi_getBasicTicketting($atts, $content = null ) 
{
	//default value for attribute if not given
    $a = shortcode_atts( array(
        'event' => 'error',
        // ...etc
    ), $atts );
	
	if($a['event'] == 'error')
	{
		echo 'you shall burn in hell you stupid';
	}
	else
	{
		echo 'yay you called the ticketing plugin';
	}
}