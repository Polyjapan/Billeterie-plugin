=== BasicTicketting ===
Contributors: Fabien Mottier, Tony Clavien
Tags: Tickets, Japan Impact
Donate link: ToBeGiven
Requires at least: 4.0.0
Tested up to: 4.3.1
License:     GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Management of the ticketing system used in Japan Impact

== Installation ==
1. call the admin
2. wait
3. cry